// cd Documents\NetBeansProjects\Armadillo4000\build\classes
// java -cp . MainClass

///////////////////////////////////////////////////////////////////
//                                                               //
//   Armadillo 4000 was created by Zack Cockle, Sean Dunbar,     //
//   Juergen Kriz, Ryan Mock, and Sunny Sunveer for INFO 2413    //
//   at Kwantlen Polytechnic University during the Spring 2018   // 
//   semester.                                                   //
//                                                               //
///////////////////////////////////////////////////////////////////


import java.util.*;

public class MainClass {

    public static void main(String[] args)throws Exception {

	// Holds financial objects for sequential evaluation
        ArrayList<FinancialObject> objects = new ArrayList();


	Scanner input = new Scanner(System.in);
        char continueLoop = 'Y';                    // Controls 'do while' loop for returning to main menu
        char menuChoice;                            // Holds Main Menu user selection
        char stockChoice;                           // Holds Monitor Options menu user selection
	String symbol;                              // Holds stock ticker symbol String value input by user
        String percentIncreaseString;               // Temporarily holds the string value of percentIncrease user input
        double percentIncrease;                     // Holds precentIncrease value as double after conversion from String
        String percentDecreaseString;               // Temporarily holds the string value of percentDecrease user input
        double percentDecrease;                     // Holds precentDecrease value as double after conversion from String
	int numberOfObjects = 0;                    // Counts number of objects created
        int rsiLength;                              // Holds Relative Simple Index length input by user in days
        int smaShortTerm;                           // Holds short-term Simple Moving Average length input by user in days
        int smaLongTerm;                            // Holds long-term Simple Moving Average length input by user in days
        char displayChoice;                         // Controls whether financial data is continuously displayed


        ///////////////////////////////////////////////////
        //                                               //
        //   Displays the Armadillo 4000 splash screen   //
        //                                               //
        ///////////////////////////////////////////////////

        System.out.println();    // Armadillo 4000 ASCII title courtesy http://www.patorjk.com/software/taag
        System.out.println();    // ASCII art armadillo courtesy https://jmilor.startlogic.com/asciiart/ARMADILO.TXT
        System.out.println();
        System.out.println("     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *");
        System.out.println("     *                                                                                           *");
        System.out.println("     *                                                                                           *");
        System.out.println("     *            _                             _ _ _ _         _  _    ___   ___   ___          *");
        System.out.println("     *           / \\   _ __ _ __ ___   __ _  __| (_) | | ___   | || |  / _ \\ / _ \\ / _ \\         *");
        System.out.println("     *          / _ \\ | '__| '_ ` _ \\ / _` |/ _` | | | |/ _ \\  | || |_| | | | | | | | | |        *");
        System.out.println("     *         / ___ \\| |  | | | | | | (_| | (_| | | | | (_) | |__   _| |_| | |_| | |_| |        *");
        System.out.println("     *        /_/   \\_\\_|  |_| |_| |_|\\__,_|\\__,_|_|_|_|\\___/     |_|  \\___/ \\___/ \\___/         *");
        System.out.println("     *                                                                                           *");
        System.out.println("     *                                         ,.-----__                                         *");
        System.out.println("     *                                      ,:::://///,:::-.                                     *");
        System.out.println("     *                                     /:''/////// ``:::`;/|/                                *");
        System.out.println("     *                                    /'   ||||||     :://'`\\                                *");
        System.out.println("     *                                  .' ,   ||||||     `/(  e \\                               *");
        System.out.println("     *                            -===~__-'\\__X_`````\\_____/~`-._ `.                             *");
        System.out.println("     *                                        ~~        ~~       `~-'                            *");
        System.out.println("     *                                                                                           *");
        System.out.println("     *                                                                                           *");
        System.out.println("     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *");
        System.out.println();
        System.out.println();
        System.out.println("                                        Press enter to continue");
        System.in.read();
        System.out.println();


        ////////////////////////////////////////////
        //                                        //
        //   Displays the Main Menu and accepts   //
        //   the user's menu selection            //
        //                                        //
        ////////////////////////////////////////////

        do {
            do {
                System.out.println();
                System.out.println();
                System.out.println("                                           M a i n   M e n u");
                System.out.println("                                      ---------------------------");
                System.out.println("                                      1 - Monitor a Stock on NYSE");
                System.out.println("                                      2 - Monitor a Cryptocurrency");
                System.out.println("                                      3 - About Armadillo 4000");
                System.out.println("                                      4 - Exit Program");
                System.out.println();
                System.out.println("                                      To make a selection, enter the");
                System.out.print("                                      corresponding number: ");
                menuChoice = input.next().charAt(0);
                System.out.println();

                if (menuChoice != '1' & menuChoice != '2' & menuChoice != '3' & menuChoice != '4') {
                    System.out.println();
                    System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                    System.out.println("                                   !!                               !!");
                    System.out.println("                                   !!   I N V A L I D   I N P U T   !!");
                    System.out.println("                                   !!   =========================   !!");
                    System.out.println("                                   !!   The Main Menu selection     !!");
                    System.out.println("                                   !!   must be a number between    !!");
                    System.out.println("                                   !!   1 and 4.                    !!");
                    System.out.println("                                   !!                               !!");
                    System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                }
            } while (menuChoice != '1' & menuChoice != '2' & menuChoice != '3' & menuChoice != '4');


            ///////////////////////////////////////////////
            //                                           //
            //   Displays the Monitor Options menu and   //
            //   accepts the user's menu selection       //
            //                                           //
            ///////////////////////////////////////////////

            System.out.println();
            if (menuChoice == '1' || menuChoice == '2') {
                if (menuChoice == '1') {
                    do {
                        System.out.println();
                        System.out.println("                                      M o n i t o r   O p t i o n s");
                        System.out.println("                                      -----------------------------");
                        System.out.println("                                      1 - Percent Increase/Decrease");
                        System.out.println("                                      2 - Relative Strength Index");
                        System.out.println("                                      3 - Simple Moving Average");
                        System.out.println();
                        System.out.println("                                      To make a selection, enter the");
                        System.out.print("                                      corresponding number: ");
                        stockChoice = input.next().charAt(0);
                        System.out.println();
                        System.out.println();

                        if (stockChoice != '1' & stockChoice != '2' & stockChoice != '3') {
                            System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                            System.out.println("                                   !!                               !!");
                            System.out.println("                                   !!   I N V A L I D   I N P U T   !!");
                            System.out.println("                                   !!   =========================   !!");
                            System.out.println("                                   !!   The Monitor Options menu    !!");
                            System.out.println("                                   !!   selection must be a number  !!");
                            System.out.println("                                   !!   between 1 and 3.            !!");
                            System.out.println("                                   !!                               !!");
                            System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                            System.out.println();
                        }
                    } while (stockChoice != '1' & stockChoice != '2' & stockChoice != '3');


                    ///////////////////////////////////////////////////////
                    //                                                   //
                    //   Creates a financial stock object monitored by   //
                    //   percent increase/decrease based on user input   //
                    //                                                   //
                    ///////////////////////////////////////////////////////

                    switch (stockChoice) {
                    case '1':
                        FinancialPrice ob4 = new FinancialPrice();
                        while (true) {
                            System.out.println("                                      Enter the ticker symbol of");
                            System.out.print("                                      a stock to monitor: ");
                            symbol = input.next().toUpperCase();
                            if (ob4.validateCall(symbol))
                                break;
                            else
                                System.out.println();
                                System.out.println();
                                System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                System.out.println("                                   !!                             !!");
                                System.out.println("                                   !!        I N V A L I D        !!");
                                System.out.println("                                   !!   S T O C K   S Y M B O L   !!");
                                System.out.println("                                   !!   =======================   !!");
                                System.out.println("                                   !!   Monitoring is available   !!");
                                System.out.println("                                   !!   only for stocks that      !!");
                                System.out.println("                                   !!   are currently traded      !!");
                                System.out.println("                                   !!   on the New York Stock     !!");
                                System.out.println("                                   !!   Exchange (NYSE).          !!");
                                System.out.println("                                   !!                             !!");
                                System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                System.out.println();
                                System.out.println();
                        }
                        ob4.setSymbol(symbol);
                        System.out.println();
                        System.out.println("                                      The current price of " + symbol + " is $1.00.");
                        do {
                            System.out.println();
                            System.out.println("                                      Enter a percent INCREASE. A notification");
                            System.out.println("                                      will be displayed when the value of " + symbol);
                            System.out.print("                                      increases by this amount: ");
                            percentIncreaseString = input.next().replaceAll("[^0-9.]","");
                            percentIncrease = Double.parseDouble(percentIncreaseString);
                            if (percentIncrease <= 0) {
                                System.out.println();
                                System.out.println();
                                System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                System.out.println("                                   !!                               !!");
                                System.out.println("                                   !!   I N V A L I D   I N P U T   !!");
                                System.out.println("                                   !!   =========================   !!");
                                System.out.println("                                   !!   The percent increase must   !!");
                                System.out.println("                                   !!   be more than 0.             !!");
                                System.out.println("                                   !!                               !!");
                                System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                System.out.println();
                            }
                        } while (percentIncrease <= 0);
                        ob4.setPercentage(percentIncrease);
                        do {
                            System.out.println();
                            System.out.println("                                      Enter a percent DECREASE. A notification");
                            System.out.println("                                      will be displayed when the value of " + symbol);
                            System.out.print("                                      decreases by this amount: ");
                            percentDecreaseString = input.next().replaceAll("[^0-9.]","");
                            percentDecrease = Double.parseDouble(percentDecreaseString);
                            if (percentDecrease <= 0 || percentDecrease > 100) {
                                System.out.println();
                                System.out.println();
                                System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                System.out.println("                                   !!                               !!");
                                System.out.println("                                   !!   I N V A L I D   I N P U T   !!");
                                System.out.println("                                   !!   =========================   !!");
                                System.out.println("                                   !!   The percent decrease must   !!");
                                System.out.println("                                   !!   be more than 0 and less     !!");
                                System.out.println("                                   !!   than or equal to 100.       !!");
                                System.out.println("                                   !!                               !!");
                                System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                System.out.println();
                            }
                        } while (percentDecrease <= 0 || percentDecrease > 100);
                        percentDecrease *= -1;
                        ob4.setPercentage(percentDecrease);
                        ob4.setInitialValues();
                        objects.add(ob4);
                        numberOfObjects ++;
                        break;


                        ///////////////////////////////////////////////////////
                        //                                                   //
                        //   Creates a financial stock object monitored by   //
                        //   Relative Strength Index based on user input     //
                        //                                                   //
                        ///////////////////////////////////////////////////////

                        case '2':
                            FinancialRSI ob3 = new FinancialRSI();
                            while (true) {
                                System.out.println("                                      Enter the ticker symbol of");
                                System.out.print("                                      a stock to monitor: ");
                                symbol = input.next().toUpperCase();
                                if (ob3.validateCall(symbol)) 
                                    break;
                                else
                                    System.out.println();
                                    System.out.println();
                                    System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                    System.out.println("                                   !!                             !!");
                                    System.out.println("                                   !!        I N V A L I D        !!");
                                    System.out.println("                                   !!   S T O C K   S Y M B O L   !!");
                                    System.out.println("                                   !!   =======================   !!");
                                    System.out.println("                                   !!   Monitoring is available   !!");
                                    System.out.println("                                   !!   only for stocks that      !!");
                                    System.out.println("                                   !!   are currently traded      !!");
                                    System.out.println("                                   !!   on the New York Stock     !!");
                                    System.out.println("                                   !!   Exchange (NYSE).          !!");
                                    System.out.println("                                   !!                             !!");
                                    System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                    System.out.println();
                                    System.out.println();
                            }
                            ob3.setSymbol(symbol);
                            do {
                                System.out.println();
                                System.out.println("                                      Enter a time period in days to");
                                System.out.println("                                      be used for the calculation of");
                                System.out.print("                                      the relative strength index: ");
                                rsiLength = input.nextInt();
                                if (rsiLength <= 0) {
                                    System.out.println();
                                    System.out.println();
                                    System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                    System.out.println("                                   !!                               !!");
                                    System.out.println("                                   !!   I N V A L I D   I N P U T   !!");
                                    System.out.println("                                   !!   =========================   !!");
                                    System.out.println("                                   !!     The time period must      !!");
                                    System.out.println("                                   !!     be more than 0 days.      !!");
                                    System.out.println("                                   !!                               !!");
                                    System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                    System.out.println();
                                }
                            } while (rsiLength <= 0);
                            objects.add(ob3);
                            numberOfObjects ++;
                            break;


                            ///////////////////////////////////////////////////////
                            //                                                   //
                            //   Creates a financial stock object monitored by   //
                            //   Simple Moving Average based on user input       //
                            //                                                   //
                            ///////////////////////////////////////////////////////

                            case '3':
                                FinancialSMA ob5 = new FinancialSMA();
                                while (true) {
                                    System.out.println("                                      Enter the ticker symbol of");
                                    System.out.print("                                      a stock to monitor: ");
                                    symbol = input.next().toUpperCase();
                                    if (ob5.validateCall(symbol)) 
                                        break;
                                    else
                                        System.out.println();
                                        System.out.println();
                                        System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                        System.out.println("                                   !!                             !!");
                                        System.out.println("                                   !!        I N V A L I D        !!");
                                        System.out.println("                                   !!   S T O C K   S Y M B O L   !!");
                                        System.out.println("                                   !!   =======================   !!");
                                        System.out.println("                                   !!   Monitoring is available   !!");
                                        System.out.println("                                   !!   only for stocks that      !!");
                                        System.out.println("                                   !!   are currently traded      !!");
                                        System.out.println("                                   !!   on the New York Stock     !!");
                                        System.out.println("                                   !!   Exchange (NYSE).          !!");
                                        System.out.println("                                   !!                             !!");
                                        System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                        System.out.println();
                                        System.out.println();
                                }
                                ob5.setSymbol(symbol);
                                do {
                                    System.out.println();
                                    System.out.println("                                      Enter the length of time in days to");
                                    System.out.println("                                      be used in the calculation of the");
                                    System.out.print("                                      SHORT-TERM simple moving average: ");
                                    smaShortTerm = input.nextInt();
                                    if (smaShortTerm <= 0) {
                                        System.out.println();
                                        System.out.println();
                                        System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                        System.out.println("                                   !!                               !!");
                                        System.out.println("                                   !!   I N V A L I D   I N P U T   !!");
                                        System.out.println("                                   !!   =========================   !!");
                                        System.out.println("                                   !!     The time period must      !!");
                                        System.out.println("                                   !!     be more than 0 days.      !!");
                                        System.out.println("                                   !!                               !!");
                                        System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                        System.out.println();
                                    }
                                } while (smaShortTerm <= 0);
                                do {
                                    System.out.println();
                                    System.out.println("                                      Enter a time period in days to");
                                    System.out.println("                                      be used for the calculation of the");
                                    System.out.print("                                      LONG-TERM simple moving average: ");
                                    smaLongTerm = input.nextInt();
                                    if (smaLongTerm <= 0) {
                                        System.out.println();
                                        System.out.println();
                                        System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                        System.out.println("                                   !!                               !!");
                                        System.out.println("                                   !!   I N V A L I D   I N P U T   !!");
                                        System.out.println("                                   !!   =========================   !!");
                                        System.out.println("                                   !!     The time period must      !!");
                                        System.out.println("                                   !!     be more than 0 days.      !!");
                                        System.out.println("                                   !!                               !!");
                                        System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                                        System.out.println();
                                    }
                                } while (smaLongTerm <= 0);
                                ob5.setinitializeSt();
                                objects.add(ob5);
                                numberOfObjects ++;
                    }
                }


                ///////////////////////////////////////////////////////
                //                                                   //
                //   Creates a crypto-currency object monitored by   //
                //   percent increase/decrease based on user input   //
                //                                                   //
                ///////////////////////////////////////////////////////

                else if (menuChoice == '2') {
                    CryptoPrice ob2 = new CryptoPrice();
                    while (true) {
                        System.out.println("                                      Enter the cryptocurrency");
                        System.out.println("                                      symbol of a digital currency");
                        System.out.print("                                      to monitor: ");
            		symbol = input.next().toUpperCase();
            		if (ob2.validateCall(symbol)) 
                            break;
         		else
                            System.out.println();
                            System.out.println();
                            System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                            System.out.println("                                   !!                           !!");
                            System.out.println("                                   !!    M O N I T O R I N G    !!");
                            System.out.println("                                   !!   U N A V A I L A B L E   !!");
                            System.out.println("                                   !!   =====================   !!");
                            System.out.println("                                   !!   Monitoring of this      !!");
                            System.out.println("                                   !!   digital currency is     !!");
                            System.out.println("                                   !!   currently unavailable.  !!");
                            System.out.println("                                   !!                           !!");
                            System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                            System.out.println();
                            System.out.println();
                    }
                    ob2.setMarket("Crypto");
                    ob2.setSymbol(symbol);
                    System.out.println();
                    System.out.println("                                      The current price of " + symbol + " is $1.00.");
                    do {
                        System.out.println();
                        System.out.println("                                      Enter a percent INCREASE. A notification");
                        System.out.println("                                      will be displayed when the value of " + symbol);
                        System.out.print("                                      increases by this amount: ");
                        percentIncreaseString = input.next().replaceAll("[^0-9.]","");
                        percentIncrease = Double.parseDouble(percentIncreaseString);
                        if (percentIncrease <= 0) {
                            System.out.println();
                            System.out.println();
                            System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                            System.out.println("                                   !!                               !!");
                            System.out.println("                                   !!   I N V A L I D   I N P U T   !!");
                            System.out.println("                                   !!   =========================   !!");
                            System.out.println("                                   !!   The percent increase must   !!");
                            System.out.println("                                   !!   be more than 0.             !!");
                            System.out.println("                                   !!                               !!");
                            System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                            System.out.println();
                        }
                    } while (percentIncrease <= 0);
                    ob2.setPercentage(percentIncrease);
                    do {
                        System.out.println();
                        System.out.println("                                      Enter a percent DECREASE. A notification");
                        System.out.println("                                      will be displayed when the value of " + symbol);
                        System.out.print("                                      decreases by this amount: ");
                        percentDecreaseString = input.next().replaceAll("[^0-9.]","");
                        percentDecrease = Double.parseDouble(percentDecreaseString);
                        if (percentDecrease <= 0 || percentDecrease > 100) {
                            System.out.println();
                            System.out.println();
                            System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                            System.out.println("                                   !!                               !!");
                            System.out.println("                                   !!   I N V A L I D   I N P U T   !!");
                            System.out.println("                                   !!   =========================   !!");
                            System.out.println("                                   !!   The percent decrease must   !!");
                            System.out.println("                                   !!   be more than 0 and less     !!");
                            System.out.println("                                   !!   than or equal to 100.       !!");
                            System.out.println("                                   !!                               !!");
                            System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                            System.out.println();
                        }
                    } while (percentDecrease <= 0 || percentDecrease > 100);
                    percentDecrease *= -1;
                    ob2.setPercentage(percentDecrease);
                    ob2.setInitialValues();
                    objects.add(ob2);
                    numberOfObjects ++;
                }


                //////////////////////////////////////////////////
                //                                              //
                //   Begins the monitoring process or returns   //
                //   to the main menu based on user input       //
                //                                              //
                //////////////////////////////////////////////////

                System.out.println();
                System.out.println();
                System.out.println("                                      --------------------------");
                System.out.println("                                      Configuration is complete.");
                System.out.println("                                      Ready to begim monitoring!");
                System.out.println("                                      --------------------------");
                System.out.println();
                do {
                    System.out.println();
                    System.out.println("                                      Would you like to return to");
                    System.out.println("                                      the main menu to configure");
                    System.out.println("                                      another item for monitoring?");
                    System.out.println();
                    System.out.println("                                      Enter Y to return to the main");
                    System.out.println("                                      menu or N to start monitoring");
                    System.out.print("                                      your financial items: ");
                    continueLoop = Character.toUpperCase(input.next().charAt(0));
                    System.out.println();
                    if (continueLoop != 'Y' && continueLoop != 'N') {
                        System.out.println();
                        System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                        System.out.println("                                   !!                               !!");
                        System.out.println("                                   !!   I N V A L I D   I N P U T   !!");
                        System.out.println("                                   !!   =========================   !!");
                        System.out.println("                                   !!     Indicate a choice by      !!");
                        System.out.println("                                   !!     entering only a Y or      !!");
                        System.out.println("                                   !!     an N.                     !!");
                        System.out.println("                                   !!                               !!");
                        System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                        System.out.println();
                    }
                } while (continueLoop != 'Y' && continueLoop != 'N');
            }


            //////////////////////////////////////////////////
            //                                              //
            //   Displays the About Armadillo 4000 screen   //
            //                                              //
            //////////////////////////////////////////////////

            else if (menuChoice == '3') {
                System.out.println();
                System.out.println("     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *");
                System.out.println("     *                                                                                           *");
                System.out.println("     *                                                                                           *");
                System.out.println("     *            _                             _ _ _ _         _  _    ___   ___   ___          *");
                System.out.println("     *           / \\   _ __ _ __ ___   __ _  __| (_) | | ___   | || |  / _ \\ / _ \\ / _ \\         *");
                System.out.println("     *          / _ \\ | '__| '_ ` _ \\ / _` |/ _` | | | |/ _ \\  | || |_| | | | | | | | | |        *");
                System.out.println("     *         / ___ \\| |  | | | | | | (_| | (_| | | | | (_) | |__   _| |_| | |_| | |_| |        *");
                System.out.println("     *        /_/   \\_\\_|  |_| |_| |_|\\__,_|\\__,_|_|_|_|\\___/     |_|  \\___/ \\___/ \\___/         *");
                System.out.println("     *                                                                                           *");
                System.out.println("     *                                         ,.-----__                                         *");
                System.out.println("     *                                      ,:::://///,:::-.                                     *");
                System.out.println("     *                                     /:''/////// ``:::`;/|/                                *");
                System.out.println("     *                                    /'   ||||||     :://'`\\                                *");
                System.out.println("     *                                  .' ,   ||||||     `/(  e \\                               *");
                System.out.println("     *                            -===~__-'\\__X_`````\\_____/~`-._ `.                             *");
                System.out.println("     *                                        ~~        ~~       `~-'                            *");
                System.out.println("     *                                                                                           *");
                System.out.println("     *                                       Version 241.3                                       *");
                System.out.println("     *                                                                                           *");
                System.out.println("     *                                                                                           *");
                System.out.println("     *                              D e v e l o p m e n t   T e a m                              *");
                System.out.println("     *                              -------------------------------                              *");
                System.out.println("     *                                                                                           *");
                System.out.println("     *          Zach Cockle                 Sean Dunbar               Juergen Kriz               *");
                System.out.println("     *          Senior Programmer           Lead Programmer           Graphic Designer           *");
                System.out.println("     *                                                                                           *");
                System.out.println("     *                         Ryan Mock                 Sunny Sunveer                           *");
                System.out.println("     *                         Systems Analyst           Project Manager                         *");
                System.out.println("     *                                                                                           *");
                System.out.println("     *                                                                                           *");
                System.out.println("     *                                S p e c i a l   T h a n k s                                *");
                System.out.println("     *                                ---------------------------                                *");
                System.out.println("     *                                                                                           *");
                System.out.println("     *                                 Jendy Wu - Project Mentor                                 *");
                System.out.println("     *                                                                                           *");
                System.out.println("     *                                                                                           *");
                System.out.println("     *                                                                                           *");
                System.out.println("     *                                                                                           *");
                System.out.println("     *                                A l s o   A v a i l a b l e                                *");
                System.out.println("     *                                  f r o m   Z o o T e c h                                  *");
                System.out.println("     *                               ============================                                *");
                System.out.println("     *                                                                                           *");
                System.out.println("     *                     Lobster 700       FireAnt 5000       Platypus 900                     *");
                System.out.println("     *                                                                                           *");
                System.out.println("     *                                                                                           *");
                System.out.println("     *                       (C) 1985-2018 ZooTech Inc. All rights reserved.                     *");
                System.out.println("     *                                                                                           *");
                System.out.println("     *                                                                                           *");
                System.out.println("     *                                                                                           *");
                System.out.println("     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *");
                System.out.println();
                System.out.println();
                System.out.println("                                         Press enter to continue");
                System.in.read();
                continueLoop = 'Y';
            }


            ///////////////////////////////////////////////////////
            //                                                   //
            //   Displays the About Armadillo 4000 exit screen   //
            //                                                   //
            ///////////////////////////////////////////////////////

            else if (menuChoice == '4') {
                System.out.println();
                System.out.println();
                System.out.println();
                System.out.println("                                      ,.-----__");
                System.out.println("                                   ,:::://///,:::-.");
                System.out.println("                                  /:''/////// ``:::`;/|/     .--------------.");
                System.out.println("                                 /'   ||||||     :://'`\\     |   Goodbye!   |");
                System.out.println("                               .' ,   ||||||     `/(  e \\    /--------------'");
                System.out.println("                         -===~__-'\\__X_`````\\_____/~`-._ `.                 ");
                System.out.println("                                     ~~        ~~       `~-'");
                System.out.println();
                System.out.println();
                System.out.println();
                System.exit(0);
            }
        } while (continueLoop == 'Y');


                //////////////////////////////////////////////
                //                                          //
                //   Continuously displays financial data   //
                //   if this option is chosen by the user   //
                //                                          //
                //////////////////////////////////////////////

                do {
                    System.out.println();
                    System.out.println("                                      Would you like to view monitored");
                    System.out.println("                                      financial data in real-time?");
                    System.out.println();
                    System.out.println("                                      Enter Y to view data in realtime");
                    System.out.println("                                      or N to begin monitoring without");
                    System.out.print("                                      realtime display: ");
                    displayChoice = Character.toUpperCase(input.next().charAt(0));
                    System.out.println();
                    if (displayChoice != 'Y' && displayChoice != 'N') {
                        System.out.println();
                        System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                        System.out.println("                                   !!                               !!");
                        System.out.println("                                   !!   I N V A L I D   I N P U T   !!");
                        System.out.println("                                   !!   =========================   !!");
                        System.out.println("                                   !!     Indicate a choice by      !!");
                        System.out.println("                                   !!     entering only a Y or      !!");
                        System.out.println("                                   !!     an N.                     !!");
                        System.out.println("                                   !!                               !!");
                        System.out.println("                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                        System.out.println();
                    }
                } while (displayChoice != 'Y' && displayChoice != 'N');

	input.close();


        /////////////////////////////////////////////////////
        //                                                 //
        //   Accesses the 'objects' ArrayList to display   //
        //   financial data for previously configured      //
        //   objects as they are monitored                 //
        //                                                 //
        /////////////////////////////////////////////////////

        System.out.println();
        while(true) {
            for(int i = 0; i < numberOfObjects; i++) {
		if(Character.toUpperCase(displayChoice) == 'Y') {
                    objects.get(i).setConsoleInput(1);
                }
		objects.get(i).compareValues();
            }
        }
    }
}